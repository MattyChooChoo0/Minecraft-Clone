#include "blocktypes.h"

GrassBlock::GrassBlock(int x, int y, int z) : Block(x, y, z) {
    // You don't need to manually assign position here; it is already handled by the Block constructor
    // Additional GrassBlock-specific initialization (if needed) can go here
}
